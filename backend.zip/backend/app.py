import os
import io
from flask import Flask, request, jsonify, render_template, redirect, url_for, session, send_file
from flask_cors import CORS
from backend.database import db
from backend.ml_model import run_sales_prediction
from backend.report_generator import generate_pdf_report, generate_excel_report
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'coconut_coir_secret_key_123')
CORS(app)

# Initialize database tables & seed data on startup
with app.app_context():
    db.initialize_database()

# -------------------------------------------------------------------------
# Session & Auth Guards
# -------------------------------------------------------------------------
@app.before_request
def require_login():
    # List of endpoints or paths that do NOT require login
    allowed_routes = ['login_page', 'login_api', 'static']
    if request.endpoint and request.endpoint not in allowed_routes:
        if 'user' not in session:
            return redirect(url_for('login_page'))

# -------------------------------------------------------------------------
# HTML Views Routes
# -------------------------------------------------------------------------
@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('dashboard_page'))
    return redirect(url_for('login_page'))

@app.route('/login')
def login_page():
    if 'user' in session:
        return redirect(url_for('dashboard_page'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard_page():
    return render_template('dashboard.html')

@app.route('/products')
def products_page():
    return render_template('products.html')

@app.route('/sales')
def sales_page():
    return render_template('sales.html')

@app.route('/analysis')
def analysis_page():
    return render_template('analysis.html')

@app.route('/prediction')
def prediction_page():
    return render_template('prediction.html')

@app.route('/demand')
def demand_page():
    return render_template('demand.html')

@app.route('/reports')
def reports_page():
    return render_template('reports.html')

# -------------------------------------------------------------------------
# REST API: Authentication
# -------------------------------------------------------------------------
@app.route('/api/login', methods=['POST'])
def login_api():
    data = request.json or {}
    username = data.get('username')
    password = data.get('password')
    role = data.get('role')
    
    if not username or not password or not role:
        return jsonify({"success": False, "message": "Missing credentials or role selection."}), 400
        
    query = "SELECT UserID, Username, Role FROM Users WHERE Username = %s AND Password = %s AND Role = %s"
    user_rows = db.execute_query(query, (username, password, role))
    
    if user_rows:
        user = user_rows[0]
        session['user'] = {
            "id": user['UserID'],
            "username": user['Username'],
            "role": user['Role']
        }
        return jsonify({"success": True, "message": "Logged in successfully.", "user": session['user']})
    else:
        return jsonify({"success": False, "message": "Invalid username, password, or role."}), 401

@app.route('/api/logout', methods=['POST'])
def logout_api():
    session.pop('user', None)
    return jsonify({"success": True, "message": "Logged out successfully."})

@app.route('/api/user-session', methods=['GET'])
def user_session_api():
    if 'user' in session:
        return jsonify({"logged_in": True, "user": session['user']})
    return jsonify({"logged_in": False}), 401

# -------------------------------------------------------------------------
# REST API: Products CRUD
# -------------------------------------------------------------------------
@app.route('/api/products', methods=['GET'])
def get_products():
    search = request.args.get('search', '')
    category = request.args.get('category', '')
    
    query = "SELECT * FROM Products WHERE 1=1"
    params = []
    
    if search:
        query += " AND ProductName LIKE %s"
        params.append(f"%{search}%")
    if category:
        query += " AND Category = %s"
        params.append(category)
        
    query += " ORDER BY ProductName ASC"
    products = db.execute_query(query, tuple(params))
    return jsonify(products)

@app.route('/api/products', methods=['POST'])
def add_product():
    if session.get('user', {}).get('role') != 'Admin':
        return jsonify({"success": False, "message": "Admin authorization required."}), 403
        
    data = request.json or {}
    name = data.get('ProductName')
    category = data.get('Category')
    price = data.get('Price')
    
    if not name or not category or price is None:
        return jsonify({"success": False, "message": "Required fields: ProductName, Category, Price."}), 400
        
    insert_query = "INSERT INTO Products (ProductName, Category, Price) VALUES (%s, %s, %s)"
    last_id = db.execute_update(insert_query, (name, category, float(price)))
    
    return jsonify({"success": True, "message": "Product added successfully.", "ProductID": last_id})

@app.route('/api/products/<int:pid>', methods=['PUT'])
def edit_product(pid):
    if session.get('user', {}).get('role') != 'Admin':
        return jsonify({"success": False, "message": "Admin authorization required."}), 403
        
    data = request.json or {}
    name = data.get('ProductName')
    category = data.get('Category')
    price = data.get('Price')
    
    if not name or not category or price is None:
        return jsonify({"success": False, "message": "Required fields: ProductName, Category, Price."}), 400
        
    update_query = "UPDATE Products SET ProductName = %s, Category = %s, Price = %s WHERE ProductID = %s"
    db.execute_update(update_query, (name, category, float(price), pid))
    
    return jsonify({"success": True, "message": "Product updated successfully."})

@app.route('/api/products/<int:pid>', methods=['DELETE'])
def delete_product(pid):
    if session.get('user', {}).get('role') != 'Admin':
        return jsonify({"success": False, "message": "Admin authorization required."}), 403
        
    delete_query = "DELETE FROM Products WHERE ProductID = %s"
    db.execute_update(delete_query, (pid,))
    
    # Also delete associated sales (optional, but maintains integrity)
    db.execute_update("DELETE FROM Sales WHERE ProductID = %s", (pid,))
    
    return jsonify({"success": True, "message": "Product and associated sales records deleted."})

# -------------------------------------------------------------------------
# REST API: Sales CRUD
# -------------------------------------------------------------------------
@app.route('/api/sales', methods=['GET'])
def get_sales():
    product_id = request.args.get('product_id', '')
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    
    query = """
        SELECT S.SaleID, S.Date, S.ProductID, P.ProductName, S.Quantity, S.Price, S.Revenue 
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        WHERE 1=1
    """
    params = []
    
    if product_id:
        query += " AND S.ProductID = %s"
        params.append(product_id)
    if start_date:
        query += " AND S.Date >= %s"
        params.append(start_date)
    if end_date:
        query += " AND S.Date <= %s"
        params.append(end_date)
        
    query += " ORDER BY S.Date DESC, S.SaleID DESC"
    sales = db.execute_query(query, tuple(params))
    return jsonify(sales)

@app.route('/api/sales', methods=['POST'])
def add_sale():
    data = request.json or {}
    pid = data.get('ProductID')
    date_str = data.get('Date')
    qty = data.get('Quantity')
    
    if not pid or not date_str or qty is None:
        return jsonify({"success": False, "message": "Required fields: ProductID, Date, Quantity."}), 400
        
    # Get price from products table
    prod_row = db.execute_query("SELECT Price, ProductName FROM Products WHERE ProductID = %s", (pid,))
    if not prod_row:
        return jsonify({"success": False, "message": "Selected product does not exist."}), 404
        
    price = float(prod_row[0]['Price'])
    revenue = int(qty) * price
    
    insert_query = "INSERT INTO Sales (Date, ProductID, Quantity, Price, Revenue) VALUES (%s, %s, %s, %s, %s)"
    last_id = db.execute_update(insert_query, (date_str, pid, int(qty), price, revenue))
    
    return jsonify({"success": True, "message": "Sale recorded successfully.", "SaleID": last_id})

@app.route('/api/sales/<int:sid>', methods=['PUT'])
def edit_sale(sid):
    data = request.json or {}
    pid = data.get('ProductID')
    date_str = data.get('Date')
    qty = data.get('Quantity')
    
    if not pid or not date_str or qty is None:
        return jsonify({"success": False, "message": "Required fields: ProductID, Date, Quantity."}), 400
        
    prod_row = db.execute_query("SELECT Price FROM Products WHERE ProductID = %s", (pid,))
    if not prod_row:
        return jsonify({"success": False, "message": "Selected product does not exist."}), 404
        
    price = float(prod_row[0]['Price'])
    revenue = int(qty) * price
    
    update_query = "UPDATE Sales SET Date = %s, ProductID = %s, Quantity = %s, Price = %s, Revenue = %s WHERE SaleID = %s"
    db.execute_update(update_query, (date_str, pid, int(qty), price, revenue, sid))
    
    return jsonify({"success": True, "message": "Sales record updated successfully."})

@app.route('/api/sales/<int:sid>', methods=['DELETE'])
def delete_sale(sid):
    delete_query = "DELETE FROM Sales WHERE SaleID = %s"
    db.execute_update(delete_query, (sid,))
    return jsonify({"success": True, "message": "Sales record deleted successfully."})

# -------------------------------------------------------------------------
# REST API: Analytics & Business Intelligence
# -------------------------------------------------------------------------
@app.route('/api/analytics/kpi', methods=['GET'])
def get_kpis():
    # 1. Total Sales Count
    qty_row = db.execute_query("SELECT SUM(Quantity) as qty FROM Sales")
    total_sales_qty = int(qty_row[0]['qty']) if qty_row and qty_row[0]['qty'] is not None else 0
    
    # 2. Total Revenue
    rev_row = db.execute_query("SELECT SUM(Revenue) as rev FROM Sales")
    total_revenue = float(rev_row[0]['rev']) if rev_row and rev_row[0]['rev'] is not None else 0.0
    
    # 3. Predicted Sales (Sum of next month's predicted quantities)
    pred_row = db.execute_query("SELECT SUM(PredictedSales) as pred FROM Predictions")
    predicted_sales = float(pred_row[0]['pred']) if pred_row and pred_row[0]['pred'] is not None else 0.0
    
    # 4. Forecasted Demand Level Count
    high_demand_row = db.execute_query("SELECT COUNT(*) as cnt FROM DemandForecast WHERE DemandLevel = 'High'")
    high_demand_count = high_demand_row[0]['cnt'] if high_demand_row else 0
    
    return jsonify({
        "total_sales_qty": total_sales_qty,
        "total_revenue": round(total_revenue, 2),
        "predicted_sales": round(predicted_sales, 2),
        "high_demand_count": high_demand_count
    })

@app.route('/api/analytics/charts', methods=['GET'])
def get_charts():
    # 1. Monthly sales trend (aggregated quantity and revenue by Year-Month)
    # Support both SQLite (strftime) and MySQL (DATE_FORMAT)
    if db.db_type == 'sqlite':
        monthly_query = """
            SELECT strftime('%Y-%m', Date) as MonthLabel, SUM(Quantity) as total_qty, SUM(Revenue) as total_rev
            FROM Sales 
            GROUP BY MonthLabel 
            ORDER BY MonthLabel ASC
        """
    else:
        monthly_query = """
            SELECT DATE_FORMAT(Date, '%Y-%m') as MonthLabel, SUM(Quantity) as total_qty, SUM(Revenue) as total_rev
            FROM Sales 
            GROUP BY MonthLabel 
            ORDER BY MonthLabel ASC
        """
    monthly_trends = db.execute_query(monthly_query)
    
    # 2. Product-wise sales breakdown (Quantity & Revenue)
    product_query = """
        SELECT P.ProductName, SUM(S.Quantity) as total_qty, SUM(S.Revenue) as total_rev
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        GROUP BY P.ProductName
        ORDER BY total_rev DESC
    """
    product_sales = db.execute_query(product_query)
    
    # 3. Category Breakdown (Pie chart data)
    category_query = """
        SELECT P.Category, SUM(S.Quantity) as total_qty, SUM(S.Revenue) as total_rev
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        GROUP BY P.Category
        ORDER BY total_rev DESC
    """
    category_sales = db.execute_query(category_query)
    
    return jsonify({
        "monthly_trends": monthly_trends,
        "product_sales": product_sales,
        "category_sales": category_sales
    })

# -------------------------------------------------------------------------
# REST API: Machine Learning (Linear Regression)
# -------------------------------------------------------------------------
@app.route('/api/predict', methods=['POST'])
def train_and_predict():
    res = run_sales_prediction()
    return jsonify(res)

@app.route('/api/predict/status', methods=['GET'])
def get_predictions_status():
    predictions = db.execute_query("SELECT * FROM Predictions ORDER BY PredictedSales DESC")
    
    # Fetch historical sales of last month for comparisons
    # SQLite vs MySQL date filter
    if db.db_type == 'sqlite':
        hist_query = """
            SELECT P.ProductName, SUM(S.Quantity) as hist_qty
            FROM Sales S
            JOIN Products P ON S.ProductID = P.ProductID
            WHERE S.Date >= date('now', '-30 days')
            GROUP BY P.ProductName
        """
    else:
        hist_query = """
            SELECT P.ProductName, SUM(S.Quantity) as hist_qty
            FROM Sales S
            JOIN Products P ON S.ProductID = P.ProductID
            WHERE S.Date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
            GROUP BY P.ProductName
        """
    hist_sales = db.execute_query(hist_query)
    
    return jsonify({
        "predictions": predictions,
        "historical_comparison": hist_sales
    })

# -------------------------------------------------------------------------
# REST API: Demand Forecast Classification
# -------------------------------------------------------------------------
@app.route('/api/forecast', methods=['GET'])
def get_demand_forecast():
    forecasts = db.execute_query("SELECT * FROM DemandForecast ORDER BY ForecastQuantity DESC")
    return jsonify(forecasts)

# -------------------------------------------------------------------------
# REST API: Report Exports (PDF & Excel)
# -------------------------------------------------------------------------
@app.route('/api/report/pdf', methods=['GET'])
def download_pdf_report():
    pdf_bytes = generate_pdf_report()
    return send_file(
        io.BytesIO(pdf_bytes),
        mimetype='application/pdf',
        as_attachment=True,
        download_name=f'coir_sales_report_{datetime.now().strftime("%Y%m%d")}.pdf'
    )

@app.route('/api/report/excel', methods=['GET'])
def download_excel_report():
    excel_bytes = generate_excel_report()
    return send_file(
        io.BytesIO(excel_bytes),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name=f'coir_sales_report_{datetime.now().strftime("%Y%m%d")}.xlsx'
    )

if __name__ == '__main__':
    # Start the server on port 5000
    app.run(host='0.0.0.0', port=5000, debug=True)
