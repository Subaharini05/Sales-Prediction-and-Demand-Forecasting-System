import os
import datetime
import io
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from backend.database import db

def get_report_data():
    """Fetches sales, product, prediction, and forecast data for the reports."""
    sales = db.execute_query("""
        SELECT S.SaleID, S.Date, P.ProductName, P.Category, S.Quantity, S.Price, S.Revenue 
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        ORDER BY S.Date DESC
    """)
    
    predictions = db.execute_query("""
        SELECT ProductName, PredictionDate, PredictedSales 
        FROM Predictions
        ORDER BY PredictedSales DESC
    """)
    
    forecasts = db.execute_query("""
        SELECT ProductName, ForecastQuantity, DemandLevel 
        FROM DemandForecast
        ORDER BY ForecastQuantity DESC
    """)
    
    # Calculate KPIs
    total_sales_qty = db.execute_query("SELECT SUM(Quantity) as qty FROM Sales")[0]['qty'] or 0
    total_revenue = db.execute_query("SELECT SUM(Revenue) as rev FROM Sales")[0]['rev'] or 0.0
    avg_sale = db.execute_query("SELECT AVG(Revenue) as avg_rev FROM Sales")[0]['avg_rev'] or 0.0
    
    # Top Selling Product
    top_selling = db.execute_query("""
        SELECT P.ProductName, SUM(S.Quantity) as qty
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        GROUP BY P.ProductName
        ORDER BY qty DESC
        LIMIT 1
    """)
    top_product = top_selling[0]['ProductName'] if top_selling else "N/A"
    
    return {
        "sales": sales,
        "predictions": predictions,
        "forecasts": forecasts,
        "kpis": {
            "total_sales_qty": int(total_sales_qty),
            "total_revenue": round(float(total_revenue), 2),
            "avg_sale": round(float(avg_sale), 2),
            "top_product": top_product
        }
    }

def generate_pdf_report():
    """Generates a professional business intelligence PDF report."""
    data = get_report_data()
    buffer = io.BytesIO()
    
    doc = SimpleDocTemplate(
        buffer,
        pagesize=letter,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )
    
    styles = getSampleStyleSheet()
    
    # Custom Styles conforming to the "Blue & White with Coconut Brown Accents" theme
    primary_color = colors.HexColor("#0B3C5D")      # Corporate Blue
    accent_color = colors.HexColor("#8B5A2B")       # Coconut Brown
    secondary_color = colors.HexColor("#328CC1")    # Sky Blue
    neutral_dark = colors.HexColor("#1D2731")       # Charcoal
    neutral_light = colors.HexColor("#F9F9F9")      # Light Off-White
    
    title_style = ParagraphStyle(
        'ReportTitle',
        parent=styles['Heading1'],
        fontName='Helvetica-Bold',
        fontSize=22,
        textColor=primary_color,
        spaceAfter=6
    )
    
    subtitle_style = ParagraphStyle(
        'ReportSubtitle',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=10,
        textColor=accent_color,
        spaceAfter=15
    )
    
    heading_style = ParagraphStyle(
        'SectionHeading',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=14,
        textColor=primary_color,
        spaceBefore=12,
        spaceAfter=8
    )
    
    body_style = ParagraphStyle(
        'ReportBody',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        textColor=neutral_dark,
        leading=12
    )
    
    table_header_style = ParagraphStyle(
        'TableHeader',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=9,
        textColor=colors.white
    )
    
    table_cell_style = ParagraphStyle(
        'TableCell',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        textColor=neutral_dark
    )
    
    story = []
    
    # 1. Header Section
    story.append(Paragraph("COCONUT COIR INDUSTRY", title_style))
    story.append(Paragraph(f"Sales Prediction & Demand Forecasting System Report — Generated on {datetime.date.today().strftime('%B %d, %Y')}", subtitle_style))
    story.append(Spacer(1, 10))
    
    # 2. KPI Section (Key Statistics Table)
    kpis = data['kpis']
    kpi_table_data = [
        [
            Paragraph("<b>Total Sales Quantity:</b>", table_cell_style),
            Paragraph(f"{kpis['total_sales_qty']:,}", table_cell_style),
            Paragraph("<b>Total Revenue:</b>", table_cell_style),
            Paragraph(f"${kpis['total_revenue']:,.2f}", table_cell_style)
        ],
        [
            Paragraph("<b>Average Sale Revenue:</b>", table_cell_style),
            Paragraph(f"${kpis['avg_sale']:,.2f}", table_cell_style),
            Paragraph("<b>Top Selling Product:</b>", table_cell_style),
            Paragraph(kpis['top_product'], table_cell_style)
        ]
    ]
    
    kpi_table = Table(kpi_table_data, colWidths=[1.8*inch, 1.8*inch, 1.8*inch, 1.8*inch])
    kpi_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), neutral_light),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('PADDING', (0,0), (-1,-1), 8),
        ('LINEBELOW', (0,0), (-1,-1), 1, colors.HexColor("#E0E0E0")),
        ('BOX', (0,0), (-1,-1), 1.5, primary_color)
    ]))
    
    story.append(Paragraph("Executive Summary KPIs", heading_style))
    story.append(kpi_table)
    story.append(Spacer(1, 15))
    
    # 3. Forecasts and Demand Predictions Section
    story.append(Paragraph("Machine Learning Sales Predictions & Demand Level Classification", heading_style))
    
    forecast_table_data = [[
        Paragraph("Product Name", table_header_style),
        Paragraph("Forecast Quantity", table_header_style),
        Paragraph("Demand Classification", table_header_style)
    ]]
    
    for f in data['forecasts']:
        # Color code demand levels
        level = f['DemandLevel']
        if level == "High":
            lvl_html = f"<font color='{accent_color.hexval()}'><b>High</b></font>"
        elif level == "Medium":
            lvl_html = f"<font color='{secondary_color.hexval()}'><b>Medium</b></font>"
        else:
            lvl_html = "Low"
            
        forecast_table_data.append([
            Paragraph(f['ProductName'], table_cell_style),
            Paragraph(f"{f['ForecastQuantity']:,.2f}", table_cell_style),
            Paragraph(lvl_html, table_cell_style)
        ])
        
    forecast_table = Table(forecast_table_data, colWidths=[3.2*inch, 2.0*inch, 2.0*inch])
    forecast_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), primary_color),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, neutral_light]),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#E0E0E0"))
    ]))
    story.append(forecast_table)
    story.append(Spacer(1, 15))
    
    # 4. Product-wise Sales performance summary
    story.append(Paragraph("Product Performance Summary (Top Selling Items)", heading_style))
    
    prod_perf = db.execute_query("""
        SELECT P.ProductName, P.Category, SUM(S.Quantity) as total_qty, SUM(S.Revenue) as total_rev
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
        GROUP BY P.ProductName, P.Category
        ORDER BY total_rev DESC
    """)
    
    prod_table_data = [[
        Paragraph("Product Name", table_header_style),
        Paragraph("Category", table_header_style),
        Paragraph("Total Qty Sold", table_header_style),
        Paragraph("Total Revenue", table_header_style)
    ]]
    
    for p in prod_perf:
        prod_table_data.append([
            Paragraph(p['ProductName'], table_cell_style),
            Paragraph(p['Category'], table_cell_style),
            Paragraph(f"{p['total_qty']:,}", table_cell_style),
            Paragraph(f"${p['total_rev']:,.2f}", table_cell_style)
        ])
        
    prod_table = Table(prod_table_data, colWidths=[2.2*inch, 2.2*inch, 1.3*inch, 1.5*inch])
    prod_table.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), primary_color),
        ('ALIGN', (0,0), (-1,-1), 'LEFT'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, neutral_light]),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor("#E0E0E0")),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 5)
    ]))
    story.append(prod_table)
    
    doc.build(story)
    buffer.seek(0)
    return buffer.getvalue()

def generate_excel_report():
    """Generates a professional formatted multi-sheet Excel workbook."""
    data = get_report_data()
    wb = Workbook()
    
    # Palette Colors
    navy_fill = PatternFill(start_color="0B3C5D", end_color="0B3C5D", fill_type="solid")
    light_blue_fill = PatternFill(start_color="E6F0F6", end_color="E6F0F6", fill_type="solid")
    brown_fill = PatternFill(start_color="8B5A2B", end_color="8B5A2B", fill_type="solid")
    zebra_fill = PatternFill(start_color="F9F9F9", end_color="F9F9F9", fill_type="solid")
    
    title_font = Font(name="Calibri", size=16, bold=True, color="0B3C5D")
    header_font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    bold_font = Font(name="Calibri", size=11, bold=True)
    regular_font = Font(name="Calibri", size=11)
    
    thin_border = Border(
        left=Side(style='thin', color='D0D0D0'),
        right=Side(style='thin', color='D0D0D0'),
        top=Side(style='thin', color='D0D0D0'),
        bottom=Side(style='thin', color='D0D0D0')
    )
    
    # -------------------------------------------------------------------------
    # SHEET 1: DASHBOARD OVERVIEW
    # -------------------------------------------------------------------------
    ws_dash = wb.active
    ws_dash.title = "Dashboard Summary"
    ws_dash.views.sheetView[0].showGridLines = True
    
    ws_dash['A1'] = "COCONUT COIR INDUSTRY - BUSINESS INTELLIGENCE DASHBOARD"
    ws_dash['A1'].font = title_font
    ws_dash['A2'] = f"Generated on {datetime.date.today().strftime('%Y-%m-%d')}"
    ws_dash['A2'].font = Font(name="Calibri", size=11, italic=True)
    
    # KPI blocks
    kpis = data['kpis']
    ws_dash['A4'] = "KPI Name"
    ws_dash['B4'] = "Value"
    ws_dash['A4'].font = header_font
    ws_dash['A4'].fill = navy_fill
    ws_dash['B4'].font = header_font
    ws_dash['B4'].fill = navy_fill
    
    kpi_rows = [
        ("Total Sales Quantity", kpis['total_sales_qty']),
        ("Total Revenue", kpis['total_revenue']),
        ("Average Sale Value", kpis['avg_sale']),
        ("Top Selling Product", kpis['top_product'])
    ]
    
    for idx, (k, v) in enumerate(kpi_rows, start=5):
        ws_dash.cell(row=idx, column=1, value=k).font = bold_font
        cell = ws_dash.cell(row=idx, column=2, value=v)
        cell.font = regular_font
        if isinstance(v, float):
            cell.number_format = '$#,##0.00'
        elif isinstance(v, int):
            cell.number_format = '#,##0'
        
        ws_dash.cell(row=idx, column=1).border = thin_border
        cell.border = thin_border
        
    # Autofit column widths
    ws_dash.column_dimensions['A'].width = 28
    ws_dash.column_dimensions['B'].width = 24
    
    # -------------------------------------------------------------------------
    # SHEET 2: DEMAND FORECAST & PREDICTIONS
    # -------------------------------------------------------------------------
    ws_fore = wb.create_sheet(title="Predictions & Forecast")
    ws_fore.views.sheetView[0].showGridLines = True
    
    ws_fore['A1'] = "Linear Regression Predictions & Demand Classification"
    ws_fore['A1'].font = title_font
    
    headers = ["Product Name", "Forecast Quantity", "Demand Level"]
    for col_idx, h in enumerate(headers, start=1):
        cell = ws_fore.cell(row=3, column=col_idx, value=h)
        cell.font = header_font
        cell.fill = navy_fill
        cell.alignment = Alignment(horizontal="center")
        
    for r_idx, f in enumerate(data['forecasts'], start=4):
        ws_fore.cell(row=r_idx, column=1, value=f['ProductName']).font = regular_font
        
        qty_cell = ws_fore.cell(row=r_idx, column=2, value=f['ForecastQuantity'])
        qty_cell.font = regular_font
        qty_cell.number_format = '#,##0.00'
        
        lvl_cell = ws_fore.cell(row=r_idx, column=3, value=f['DemandLevel'])
        lvl_cell.font = bold_font
        lvl_cell.alignment = Alignment(horizontal="center")
        
        # Color code demand
        if f['DemandLevel'] == "High":
            lvl_cell.font = Font(name="Calibri", size=11, bold=True, color="8B5A2B") # Brown
        elif f['DemandLevel'] == "Medium":
            lvl_cell.font = Font(name="Calibri", size=11, bold=True, color="328CC1") # Blue
            
        for c in range(1, 4):
            cell = ws_fore.cell(row=r_idx, column=c)
            cell.border = thin_border
            if r_idx % 2 == 1:
                cell.fill = zebra_fill
                
    ws_fore.column_dimensions['A'].width = 28
    ws_fore.column_dimensions['B'].width = 22
    ws_fore.column_dimensions['C'].width = 18

    # -------------------------------------------------------------------------
    # SHEET 3: HISTORICAL SALES
    # -------------------------------------------------------------------------
    ws_sales = wb.create_sheet(title="Historical Sales History")
    ws_sales.views.sheetView[0].showGridLines = True
    
    ws_sales['A1'] = "Detailed Sales Transaction Ledger"
    ws_sales['A1'].font = title_font
    
    sales_headers = ["Sale ID", "Date", "Product Name", "Category", "Quantity", "Price", "Revenue"]
    for col_idx, sh in enumerate(sales_headers, start=1):
        cell = ws_sales.cell(row=3, column=col_idx, value=sh)
        cell.font = header_font
        cell.fill = navy_fill
        cell.alignment = Alignment(horizontal="center")
        
    for r_idx, s in enumerate(data['sales'], start=4):
        ws_sales.cell(row=r_idx, column=1, value=s['SaleID']).font = regular_font
        
        # Format Date
        date_val = s['Date']
        if isinstance(date_val, str):
            ws_sales.cell(row=r_idx, column=2, value=date_val).font = regular_font
        else:
            ws_sales.cell(row=r_idx, column=2, value=date_val.strftime('%Y-%m-%d')).font = regular_font
            
        ws_sales.cell(row=r_idx, column=3, value=s['ProductName']).font = regular_font
        ws_sales.cell(row=r_idx, column=4, value=s['Category']).font = regular_font
        
        qty_c = ws_sales.cell(row=r_idx, column=5, value=s['Quantity'])
        qty_c.font = regular_font
        qty_c.number_format = '#,##0'
        
        prc_c = ws_sales.cell(row=r_idx, column=6, value=float(s['Price']))
        prc_c.font = regular_font
        prc_c.number_format = '$#,##0.00'
        
        rev_c = ws_sales.cell(row=r_idx, column=7, value=float(s['Revenue']))
        rev_c.font = regular_font
        rev_c.number_format = '$#,##0.00'
        
        for c in range(1, 8):
            cell = ws_sales.cell(row=r_idx, column=c)
            cell.border = thin_border
            if r_idx % 2 == 1:
                cell.fill = zebra_fill
                
    ws_sales.column_dimensions['A'].width = 12
    ws_sales.column_dimensions['B'].width = 15
    ws_sales.column_dimensions['C'].width = 25
    ws_sales.column_dimensions['D'].width = 30
    ws_sales.column_dimensions['E'].width = 12
    ws_sales.column_dimensions['F'].width = 12
    ws_sales.column_dimensions['G'].width = 15
    
    # Save to memory stream
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.getvalue()
