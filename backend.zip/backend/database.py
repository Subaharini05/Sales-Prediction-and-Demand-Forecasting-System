import os
import sqlite3
import datetime
import random
import mysql.connector
from mysql.connector import errorcode

# Configuration defaults
DB_HOST = os.environ.get('DB_HOST', 'localhost')
DB_USER = os.environ.get('DB_USER', 'root')
DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
DB_NAME = os.environ.get('DB_NAME', 'coir_industry_db')

class DatabaseManager:
    def __init__(self):
        self.db_type = 'sqlite'  # default fallback
        self.sqlite_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'coir_db.sqlite')
        self.test_connection()

    def test_connection(self):
        """Test MySQL connection. If fails, fall back to SQLite."""
        try:
            # Attempt to connect to MySQL server
            conn = mysql.connector.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASSWORD,
                connect_timeout=3
            )
            cursor = conn.cursor()
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
            conn.commit()
            cursor.close()
            conn.close()

            # Now test connecting to the specific database
            conn = mysql.connector.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASSWORD,
                database=DB_NAME,
                connect_timeout=3
            )
            conn.close()
            self.db_type = 'mysql'
            print("Successfully connected to MySQL database.")
        except Exception as e:
            print(f"MySQL connection failed ({e}). Falling back to SQLite: {self.sqlite_path}")
            self.db_type = 'sqlite'

    def get_connection(self):
        if self.db_type == 'mysql':
            return mysql.connector.connect(
                host=DB_HOST,
                user=DB_USER,
                password=DB_PASSWORD,
                database=DB_NAME
            )
        else:
            conn = sqlite3.connect(self.sqlite_path)
            conn.row_factory = sqlite3.Row
            return conn

    def format_query(self, query):
        """Translate query placeholder %s to ? for SQLite."""
        if self.db_type == 'sqlite':
            return query.replace('%s', '?')
        return query

    def execute_query(self, query, params=None):
        """Execute a query returning rows."""
        conn = self.get_connection()
        cursor = conn.cursor()
        formatted_query = self.format_query(query)
        try:
            if params:
                cursor.execute(formatted_query, params)
            else:
                cursor.execute(formatted_query)
            
            # Fetch all and map keys if sqlite
            if self.db_type == 'sqlite':
                columns = [col[0] for col in cursor.description] if cursor.description else []
                results = [dict(zip(columns, row)) for row in cursor.fetchall()]
            else:
                columns = [col[0] for col in cursor.description] if cursor.description else []
                results = [dict(zip(columns, row)) for row in cursor.fetchall()]
                
            return results
        except Exception as e:
            print(f"Database error executing query: {query}. Error: {e}")
            raise e
        finally:
            cursor.close()
            conn.close()

    def execute_update(self, query, params=None):
        """Execute insert, update, or delete query. Returns lastrowid."""
        conn = self.get_connection()
        cursor = conn.cursor()
        formatted_query = self.format_query(query)
        try:
            if params:
                cursor.execute(formatted_query, params)
            else:
                cursor.execute(formatted_query)
            conn.commit()
            last_id = cursor.lastrowid
            return last_id
        except Exception as e:
            print(f"Database error executing update: {query}. Error: {e}")
            conn.rollback()
            raise e
        finally:
            cursor.close()
            conn.close()

    def execute_script(self, script_content):
        """Runs a complete SQL script file, adapting for SQLite if needed."""
        conn = self.get_connection()
        try:
            if self.db_type == 'sqlite':
                # Adapt MySQL schema syntax to SQLite
                adapted = script_content
                adapted = adapted.replace("INT AUTO_INCREMENT PRIMARY KEY", "INTEGER PRIMARY KEY AUTOINCREMENT")
                adapted = adapted.replace("DECIMAL(10, 2)", "REAL")
                adapted = adapted.replace("DOUBLE", "REAL")
                # SQLite executes scripts using executescript
                conn.executescript(adapted)
            else:
                cursor = conn.cursor()
                # Split statements for MySQL connection
                statements = script_content.split(';')
                for statement in statements:
                    if statement.strip():
                        cursor.execute(statement)
                conn.commit()
                cursor.close()
        except Exception as e:
            print(f"Script execution failed: {e}")
            raise e
        finally:
            conn.close()

    def initialize_database(self):
        """Initialize schema and seed initial data if empty."""
        schema_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'schema.sql')
        if os.path.exists(schema_path):
            with open(schema_path, 'r') as f:
                schema_content = f.read()
            self.execute_script(schema_content)
            print("Database schema loaded successfully.")
            self.seed_if_empty()
        else:
            print("schema.sql not found! Cannot initialize database.")

    def seed_if_empty(self):
        """Seed tables with realistic data if they have no users or products."""
        user_check = self.execute_query("SELECT COUNT(*) as cnt FROM Users")
        product_check = self.execute_query("SELECT COUNT(*) as cnt FROM Products")
        
        if user_check[0]['cnt'] == 0:
            print("Seeding Users...")
            # We seed users. For passwords, using plain text for this educational implementation
            # or a basic hash. Let's use simple passwords.
            self.execute_update(
                "INSERT INTO Users (Username, Password, Role) VALUES (%s, %s, %s)",
                ("admin", "admin123", "Admin")
            )
            self.execute_update(
                "INSERT INTO Users (Username, Password, Role) VALUES (%s, %s, %s)",
                ("user", "user123", "User")
            )
            
        if product_check[0]['cnt'] == 0:
            print("Seeding Products...")
            products = [
                ("Coir Mat", "Mats & Flooring Products", 15.00),
                ("Coir Door Mat", "Mats & Flooring Products", 8.50),
                ("Coir Pith Block", "Agricultural & Horticultural Products", 5.00),
                ("Coir Grow Bag", "Agricultural & Horticultural Products", 4.20),
                ("Coir Pot", "Agricultural & Horticultural Products", 2.50),
                ("Coir Mulch Mat", "Agricultural & Horticultural Products", 3.00),
                ("Coir Rope", "Industrial & Fibre Products", 12.00),
                ("Coir Yarn", "Industrial & Fibre Products", 10.00),
                ("Coir Fibre", "Industrial & Fibre Products", 7.50),
                ("Coir Geo Textile", "Industrial & Fibre Products", 18.00)
            ]
            for p in products:
                self.execute_update(
                    "INSERT INTO Products (ProductName, Category, Price) VALUES (%s, %s, %s)",
                    p
                )
            
            # Since we just seeded products, let's also seed sales records to build a realistic 1-year history.
            sales_check = self.execute_query("SELECT COUNT(*) as cnt FROM Sales")
            if sales_check[0]['cnt'] == 0:
                print("Seeding Sales data...")
                db_products = self.execute_query("SELECT ProductID, ProductName, Price FROM Products")
                
                # Start date: 1 year ago
                start_date = datetime.date.today() - datetime.timedelta(days=365)
                end_date = datetime.date.today()
                
                curr_date = start_date
                sales_to_insert = []
                
                while curr_date <= end_date:
                    # Let's generate daily sales records
                    # Each day, 2-5 random products get sales
                    num_sales = random.randint(2, 5)
                    selected_products = random.sample(db_products, num_sales)
                    
                    # We can introduce seasonal variations (e.g. more agricultural sales in spring/summer,
                    # and mats in winter) to make linear regression patterns interesting!
                    month = curr_date.month
                    for prod in selected_products:
                        qty_base = random.randint(10, 50)
                        
                        # Add seasonality factors
                        season_factor = 1.0
                        if prod['ProductName'] in ["Coir Pith Block", "Coir Grow Bag", "Coir Pot", "Coir Mulch Mat"]:
                            # Higher in spring (March - May)
                            if month in [3, 4, 5]:
                                season_factor = 1.6
                            elif month in [6, 7, 8]:
                                season_factor = 1.3
                        elif prod['ProductName'] in ["Coir Mat", "Coir Door Mat"]:
                            # Higher in holiday season / winter (Nov - Jan)
                            if month in [11, 12, 1]:
                                season_factor = 1.5
                        
                        quantity = int(qty_base * season_factor)
                        price = float(prod['Price'])
                        revenue = quantity * price
                        
                        self.execute_update(
                            "INSERT INTO Sales (Date, ProductID, Quantity, Price, Revenue) VALUES (%s, %s, %s, %s, %s)",
                            (curr_date.strftime("%Y-%m-%d"), prod['ProductID'], quantity, price, revenue)
                        )
                    curr_date += datetime.timedelta(days=1)
                
                print("Sales seeding complete.")

db = DatabaseManager()
