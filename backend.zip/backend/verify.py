import sys
import os

# Adjust path to import backend modules
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database import db
from backend.ml_model import run_sales_prediction
from backend.report_generator import generate_pdf_report, generate_excel_report

def run_verification():
    print("=== STARTING COCONUT COIR BI SYSTEM VERIFICATION ===")
    
    # 1. Test database initialization
    print("\n1. Initializing Database Schema...")
    try:
        db.initialize_database()
        print("[OK] Database initialized successfully.")
    except Exception as e:
        print(f"[FAIL] Database initialization failed: {e}")
        return False
        
    # 2. Check users seeded
    print("\n2. Checking Seeded Users...")
    try:
        users = db.execute_query("SELECT Username, Role FROM Users")
        print(f"[OK] Found {len(users)} users in database:")
        for u in users:
            print(f"  - {u['Username']} ({u['Role']})")
    except Exception as e:
        print(f"[FAIL] Failed to query users: {e}")
        return False
        
    # 3. Check products seeded
    print("\n3. Checking Seeded Products...")
    try:
        products = db.execute_query("SELECT ProductID, ProductName, Price FROM Products")
        print(f"[OK] Found {len(products)} products in database.")
    except Exception as e:
        print(f"[FAIL] Failed to query products: {e}")
        return False

    # 4. Check sales records
    print("\n4. Checking Seeded Sales Ledger...")
    try:
        sales_count = db.execute_query("SELECT COUNT(*) as count FROM Sales")[0]['count']
        print(f"[OK] Found {sales_count} historical sales transactions.")
    except Exception as e:
        print(f"[FAIL] Failed to query sales: {e}")
        return False

    # 5. Test Linear Regression Model Training & Prediction
    print("\n5. Testing Linear Regression ML Training...")
    try:
        res = run_sales_prediction()
        if res.get('success'):
            print(f"[OK] ML Prediction completed successfully. Results generated for {len(res.get('results', []))} products.")
        else:
            print(f"[FAIL] ML Prediction failed: {res.get('message')}")
            return False
    except Exception as e:
        print(f"[FAIL] ML Training crashed: {e}")
        return False

    # 6. Test PDF report rendering
    print("\n6. Testing PDF Report Generation...")
    try:
        pdf_bytes = generate_pdf_report()
        print(f"[OK] PDF successfully generated in memory ({len(pdf_bytes)} bytes).")
    except Exception as e:
        print(f"[FAIL] PDF generation failed: {e}")
        return False

    # 7. Test Excel report rendering
    print("\n7. Testing Excel Sheet Generation...")
    try:
        excel_bytes = generate_excel_report()
        print(f"[OK] Excel Workbook successfully generated in memory ({len(excel_bytes)} bytes).")
    except Exception as e:
        print(f"[FAIL] Excel generation failed: {e}")
        return False

    print("\n=== ALL SUBSYSTEMS VERIFIED SUCCESSFULLY ===")
    return True

if __name__ == '__main__':
    success = run_verification()
    sys.exit(0 if success else 1)
