// Shared JavaScript logic for the Coconut Coir BI System

// Set today's date in header
const dateDisplay = document.getElementById('current-date');
if (dateDisplay) {
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    dateDisplay.innerText = new Date().toLocaleDateString('en-US', options);
}

// Global user session cache
let currentUser = null;

// Fetch and cache logged in user details
async function getSessionUser() {
    if (currentUser) return currentUser;
    try {
        const response = await fetch('/api/user-session');
        if (response.ok) {
            const data = await response.json();
            if (data.logged_in) {
                currentUser = data.user;
                updateSidebarUser(currentUser);
                return currentUser;
            }
        }
    } catch (e) {
        console.error("Failed to fetch user session", e);
    }
    return null;
}

// Update sidebar profile card
function updateSidebarUser(user) {
    const usernameEl = document.getElementById('session-username');
    const roleEl = document.getElementById('session-role');
    const avatarEl = document.getElementById('avatar-letter');
    
    if (usernameEl) usernameEl.innerText = user.username;
    if (roleEl) roleEl.innerText = user.role;
    if (avatarEl) avatarEl.innerText = user.username.charAt(0).toUpperCase();
}

// Highlight active page link in sidebar
function setActiveMenu(menuId) {
    // Remove active class from all menu items
    const menuItems = document.querySelectorAll('.sidebar-menu li');
    menuItems.forEach(item => item.classList.remove('active'));
    
    // Add active class to target
    const activeItem = document.getElementById(menuId);
    if (activeItem) {
        activeItem.classList.add('active');
    }
}

// Alert helper
function showAlert(elementId, message, type = 'success') {
    const alertDiv = document.getElementById(elementId);
    if (alertDiv) {
        alertDiv.innerText = message;
        alertDiv.className = `alert alert-${type}`;
        alertDiv.style.display = 'block';
        
        // Auto hide after 4 seconds
        setTimeout(() => {
            alertDiv.style.display = 'none';
        }, 4000);
    }
}

// HTML escaping helper to prevent XSS
function escapeHtml(string) {
    return String(string).replace(/[&<>"']/g, function (s) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[s];
    });
}

// Logout handler
const logoutBtn = document.getElementById('logout-btn');
if (logoutBtn) {
    logoutBtn.addEventListener('click', async function() {
        if (confirm("Are you sure you want to log out?")) {
            try {
                const response = await fetch('/api/logout', { method: 'POST' });
                if (response.ok) {
                    window.location.href = '/login';
                }
            } catch (e) {
                console.error("Error logging out", e);
            }
        }
    });
}

// Auto-trigger session lookup on script load
getSessionUser();
