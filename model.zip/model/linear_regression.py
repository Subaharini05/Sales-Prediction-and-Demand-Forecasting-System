import datetime

def fit_linear_regression(x, y):
    """
    Fits a simple linear regression y = m * x + c using Ordinary Least Squares.
    Returns (slope, intercept). If len(x) < 2, returns (0, y[0]) or (0, 0).
    """
    n = len(x)
    if n < 1:
        return 0.0, 0.0
    if n == 1:
        return 0.0, float(y[0])
        
    mean_x = sum(x) / n
    mean_y = sum(y) / n
    
    num = 0.0
    den = 0.0
    for xi, yi in zip(x, y):
        num += (xi - mean_x) * (yi - mean_y)
        den += (xi - mean_x) ** 2
        
    if den == 0.0:
        return 0.0, mean_y
        
    slope = num / den
    intercept = mean_y - slope * mean_x
    return slope, intercept

def run_sales_prediction(db):
    """
    Trains a Linear Regression model for each product using historical monthly sales.
    Predicts sales for the next month, classifies the demand level, and writes
    the results to the Predictions and DemandForecast tables.
    """
    # 1. Fetch sales data joined with products
    query = """
        SELECT S.Date, P.ProductName, S.Quantity, S.Revenue 
        FROM Sales S
        JOIN Products P ON S.ProductID = P.ProductID
    """
    sales_data = db.execute_query(query)
    
    if not sales_data:
        return {"success": False, "message": "No historical sales data found to train model."}
        
    # Group by product, year, month and sum quantity
    monthly_groups = {}
    for row in sales_data:
        prod_name = row['ProductName']
        date_val = row['Date']
        
        # Parse date_val
        if isinstance(date_val, str):
            try:
                dt = datetime.datetime.strptime(date_val[:10], "%Y-%m-%d")
            except Exception:
                continue
        elif isinstance(date_val, datetime.date) or isinstance(date_val, datetime.datetime):
            dt = date_val
        else:
            continue
            
        year = dt.year
        month = dt.month
        qty = int(row['Quantity'])
        
        key = (prod_name, year, month)
        monthly_groups[key] = monthly_groups.get(key, 0) + qty
        
    # Format into chronological lists per product
    products_data = {}
    for (prod_name, year, month), qty in monthly_groups.items():
        if prod_name not in products_data:
            products_data[prod_name] = []
        products_data[prod_name].append((year, month, qty))
        
    # Clear predictions
    db.execute_update("DELETE FROM Predictions")
    db.execute_update("DELETE FROM DemandForecast")
    
    prediction_results = []
    today = datetime.date.today()
    if today.month == 12:
        next_month_date = datetime.date(today.year + 1, 1, 1)
    else:
        next_month_date = datetime.date(today.year, today.month + 1, 1)
    next_month_str = next_month_date.strftime("%Y-%m-%d")
    
    for prod_name, records in products_data.items():
        # Sort chronologically by year and month
        records.sort(key=lambda r: (r[0], r[1]))
        
        # Create X (Time index: 1, 2, 3...) and y (Quantity)
        x_vals = list(range(1, len(records) + 1))
        y_vals = [r[2] for r in records]
        
        # Fit model
        slope, intercept = fit_linear_regression(x_vals, y_vals)
        
        # Predict next step
        next_x = len(x_vals) + 1
        predicted_val = slope * next_x + intercept
        
        # Prevent negative values
        predicted_val = max(0.0, float(predicted_val))
        predicted_val = round(predicted_val, 2)
        
        # Save to database
        db.execute_update(
            "INSERT INTO Predictions (ProductName, PredictionDate, PredictedSales) VALUES (%s, %s, %s)",
            (prod_name, next_month_str, predicted_val)
        )
        
        # Classify demand
        if predicted_val > 2000:
            demand_level = "High"
        elif predicted_val >= 1000:
            demand_level = "Medium"
        else:
            demand_level = "Low"
            
        db.execute_update(
            "INSERT INTO DemandForecast (ProductName, ForecastQuantity, DemandLevel) VALUES (%s, %s, %s)",
            (prod_name, predicted_val, demand_level)
        )
        
        prediction_results.append({
            "product_name": prod_name,
            "prediction_date": next_month_str,
            "predicted_sales": predicted_val,
            "demand_level": demand_level
        })
        
    return {
        "success": True, 
        "message": f"Predictions completed successfully for {len(prediction_results)} products (Pure Python Engine).",
        "results": prediction_results
    }
