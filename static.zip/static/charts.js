// charts.js - Reusable Chart.js rendering functions for the Coconut Coir BI System

// ---- Chart instance references (for destroy before re-render) ----
let monthlySalesChartInstance = null;
let revenueTrendChartInstance = null;
let actualVsPredictedChartInstance = null;
let analysisTrendChartInstance = null;
let productPerfChartInstance = null;
let categoryPerfChartInstance = null;
let predictionChartInstance = null;
let demandRankChartInstance = null;
let demandDistributionChartInstance = null;

// ---- Dashboard Charts ----
function renderMonthlySalesLine(labels, data) {
    if (monthlySalesChartInstance) monthlySalesChartInstance.destroy();
    const ctx = document.getElementById('monthlySalesChart').getContext('2d');
    monthlySalesChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Quantity Sold',
                data: data,
                borderColor: '#328CC1',
                backgroundColor: 'rgba(50,140,193,0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { grid: { color: '#E2E8F0' } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderMonthlyRevenueBar(labels, data) {
    if (revenueTrendChartInstance) revenueTrendChartInstance.destroy();
    const ctx = document.getElementById('revenueTrendChart').getContext('2d');
    revenueTrendChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Revenue ($)',
                data: data,
                backgroundColor: '#8B5A2B',
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { grid: { color: '#E2E8F0' } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderCompareBar(labels, actual, predicted) {
    if (actualVsPredictedChartInstance) actualVsPredictedChartInstance.destroy();
    const ctx = document.getElementById('actualVsPredictedChart').getContext('2d');
    actualVsPredictedChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Actual Sales (Last 30 Days)',
                    data: actual,
                    backgroundColor: '#0B3C5D',
                    borderRadius: 4
                },
                {
                    label: 'Predicted Sales (Next Month)',
                    data: predicted,
                    backgroundColor: '#8B5A2B',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { font: { family: 'Outfit' } } }
            },
            scales: {
                y: { grid: { color: '#E2E8F0' } },
                x: { grid: { display: false } }
            }
        }
    });
}

// ---- Analysis Charts ----
function renderAnalysisTrend(labels, qty, rev) {
    if (analysisTrendChartInstance) analysisTrendChartInstance.destroy();
    const ctx = document.getElementById('analysisTrendChart').getContext('2d');
    analysisTrendChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Quantity Sold',
                    data: qty,
                    borderColor: '#328CC1',
                    backgroundColor: 'rgba(50,140,193,0.1)',
                    borderWidth: 2,
                    yAxisID: 'y-qty',
                    tension: 0.3,
                    fill: true
                },
                {
                    label: 'Revenue ($)',
                    data: rev,
                    borderColor: '#8B5A2B',
                    backgroundColor: 'rgba(139,90,43,0.1)',
                    borderWidth: 2,
                    yAxisID: 'y-rev',
                    tension: 0.3,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                'y-qty': { type: 'linear', position: 'left', grid: { color: '#E2E8F0' } },
                'y-rev': { type: 'linear', position: 'right', grid: { display: false } },
                x: { grid: { display: false } }
            }
        }
    });
}

function renderProductPerf(labels, data) {
    if (productPerfChartInstance) productPerfChartInstance.destroy();
    const ctx = document.getElementById('productPerfChart').getContext('2d');
    productPerfChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Revenue ($)',
                data: data,
                backgroundColor: '#0B3C5D',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: '#E2E8F0' } },
                y: { grid: { display: false } }
            }
        }
    });
}

function renderCategoryPerf(labels, data) {
    if (categoryPerfChartInstance) categoryPerfChartInstance.destroy();
    const ctx = document.getElementById('categoryPerfChart').getContext('2d');
    categoryPerfChartInstance = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: ['#0B3C5D', '#8B5A2B', '#328CC1']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}

// ---- Prediction Chart ----
function renderPredictionCompare(labels, actual, predicted) {
    if (predictionChartInstance) predictionChartInstance.destroy();
    const ctx = document.getElementById('predictionComparisonChart').getContext('2d');
    predictionChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Actual (Recent 30 Days)',
                    data: actual,
                    backgroundColor: '#0B3C5D',
                    borderRadius: 4
                },
                {
                    label: 'Predicted (Next Month)',
                    data: predicted,
                    backgroundColor: '#8B5A2B',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom' } },
            scales: {
                y: { grid: { color: '#E2E8F0' } },
                x: { grid: { display: false } }
            }
        }
    });
}

// ---- Demand Charts ----
function renderDemandForecastCharts(forecasts) {
    const sorted = [...forecasts].sort((a, b) => b.ForecastQuantity - a.ForecastQuantity);
    const prodNames = sorted.map(f => f.ProductName);
    const prodQtys = sorted.map(f => f.ForecastQuantity);

    let highCount = 0, medCount = 0, lowCount = 0;
    forecasts.forEach(f => {
        if (f.DemandLevel === "High") highCount++;
        else if (f.DemandLevel === "Medium") medCount++;
        else lowCount++;
    });

    // Rank chart
    if (demandRankChartInstance) demandRankChartInstance.destroy();
    const ctxRank = document.getElementById('demandRankChart').getContext('2d');
    demandRankChartInstance = new Chart(ctxRank, {
        type: 'bar',
        data: {
            labels: prodNames,
            datasets: [{
                label: 'Forecast Quantity',
                data: prodQtys,
                backgroundColor: sorted.map(f =>
                    f.DemandLevel === 'High' ? '#8B5A2B' :
                    f.DemandLevel === 'Medium' ? '#328CC1' : '#A0AEC0'
                ),
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: 'y',
            plugins: { legend: { display: false } },
            scales: {
                x: { grid: { color: '#E2E8F0' } },
                y: { grid: { display: false } }
            }
        }
    });

    // Segment doughnut
    if (demandDistributionChartInstance) demandDistributionChartInstance.destroy();
    const ctxDist = document.getElementById('demandDistributionChart').getContext('2d');
    demandDistributionChartInstance = new Chart(ctxDist, {
        type: 'doughnut',
        data: {
            labels: ['High Demand (>2000)', 'Medium Demand (1000-2000)', 'Low Demand (<1000)'],
            datasets: [{
                data: [highCount, medCount, lowCount],
                backgroundColor: ['#8B5A2B', '#328CC1', '#CBD5E1']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'bottom' }
            }
        }
    });
}
